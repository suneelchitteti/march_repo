x={}
print(x)
print(type(x))
y=dict()
print(y)
print(type(y))
z={"python":99,"java":98,"aws":85,"haddop":80}
print(z)
print(z['python'])
z["pega"]=87
print(z)
print('python' in z)
print(99 in z)
for p in z:
    print(p,z[p])
k=z.keys()
for l in k:
    print(l)
l=z.values()
for m in l:
    print(m)
kv=z.items()
for p in kv:
    print(p)
for a,b in kv:
    print(a,b)
