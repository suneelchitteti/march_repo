print("begin")
i=1
while i<=5:
    print("welcome",i)
    i=i+1
print("end")
##print("******next method******")
##print("begin")
##x=input("enter number:")
##i=int(x)
##while i<=100:
  ##  print("welcome",i)
    ##i=i+1
print("*******next program****")
i=1
s=0
while i<=10:
    s=s+i
    i=i+1
print(s)

