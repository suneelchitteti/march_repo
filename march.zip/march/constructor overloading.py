class x:
    def __init__(self):
        print("no param in class x")
    def __init__(self,a):
        print("one param in class x")
    def __init__(self,a,b):
        print("two param in class x")
x1=x(10,20)
 
