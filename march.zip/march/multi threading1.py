import threading
class x(threading.Thread):
    def run(self):
        myfunc()
class y(threading.Thread):
    def run(self):
        myfunc()
def myfunc():
    for i in range(1,10):
        print(i)
x1=x()
x1.start()
y1=y()
y1.start()
