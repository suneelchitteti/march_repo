class x:
    a=100
    def __init__(self):
        self.b=200
    def m1(self):
        print("in m1 of class x")
class y:
    c=300
    def __init__(self):
        self.d=400
    def m2(self):
        print("in m2 of class y")
    def display(self):
        print(y.c)
        print(self.d)
        self.m2()
        print(x.a)
        x1=x()
        print(x1.b)
        x1.m1()
y1=y()
y1.display()
