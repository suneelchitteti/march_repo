def add(a,b):
    c=a+b
    return c
p=add(100,200)
print(p)
add(123,123)
