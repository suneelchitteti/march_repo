x=int(input("enter a number:"))
factorial=1
if x<0:
    print("the factorial does not support the negitive numbers please enter positive numbers")
elif x==0:
    print("the factorial of 0 is 1")
else:
    for i in range(1,x+1):
        factorial=factorial*i
    print("the factrial of",x,"is",factorial)
    
