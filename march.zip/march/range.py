a=range(10)
for p in a:
    print(p)
b=range(10,20)
for q in b:
    print(q)
c=range(20,30,2)
for r in c:
    print(r)
d=range(50,40,-2)
for s in d:
    print(s)
