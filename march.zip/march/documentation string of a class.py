class Demo:
    """sample class to test the documentation string"""
    print(Demo.__doc__)
    print(list.__str__)
    
