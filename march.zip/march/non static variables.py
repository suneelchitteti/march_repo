class Test:
    def insert(self):
        self.a=1000
        self.b=2000
    def display(self):
        print(self.a)
        print(self.b)
t1=Test()
print(t1)
t1.insert()
t1.display()
t2=Test()
print(t2)
t2.insert()
t2.display()
