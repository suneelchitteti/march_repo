class x:
    a=100
    def __init__(self):
        self.b=200
    def m1(self):
        print("in m1 of class x")
class y(x):
    c=300
    def __init__(self):
        self.d=400
        super().__init__()
    def m2(self):
        print("in m2 of class y")
        
        
y1=y()
print(y1.a)
print(y1.b)
print(y1.c)
print(y1.d)
