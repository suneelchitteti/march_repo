class Test:
    def __init__(self,cacno,cname,cadd,cbal):
        self.cacno=cacno
        self.cname=cname
        self.cadd=cadd
        self.cbal=cbal
    def deposit(self,damt):
        self.cbal=self.cbal+damt
    def withdraw(self,wamt):
        self.cbal=self.cbal-wamt
    def display(self):
        print(self.cacno)
        print(self.cname)
        print(self.cadd)
        print(self.cbal)
t1=Test(101,"suneel","thonukumala",100000.00)
print(t1)
t1.display()
t1.deposit(100000.00)
t1.display()
t1.withdraw(100000.00)
t1.display()
t2=Test(102,"seetha","ayodhya",200000.00)
print(t2)
t2.display()
t2.deposit(200000.00)
t2.display()
t2.withdraw(50000.00)
t2.display()
        
