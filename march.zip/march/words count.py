s=input("enter a sentance:")
r=len(s.split())
print(r)
