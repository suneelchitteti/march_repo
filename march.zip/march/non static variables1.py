class Test:
    def insert(self):
        self.a=1000
        self.b=2000
    def display(self):
        print(self.a)
        print(self.b)
    def modify(self):
        self.a=self.a+100
        self.b=self.b-100
t1=Test()
print("this is the first object")
print(t1)
t1.insert()
print("before modifying the data")
t1.display()
t1.modify()
print("after modifying the data")
t1.display()
t2=Test()
print("second object")
print(t2)
t2.insert()
t2.display()
t2.modify()
t2.display() 
