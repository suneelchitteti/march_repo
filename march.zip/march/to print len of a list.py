a=["abc","ab","abcd"]
b=list(map(len,a))
print(b)
print("****next program**************")
a=[1,2,3],[4,5,6]
b=list(map(sum,zip([1,2,3],[4,5,6])))
print(b)
print("*********next program********")
a=[1,2,3,[4,5,6],7,[8,9,10]]
b=[]
for i in a:
    if type(i)==int:
        b.append(i)
    if type(i)==list:
        for j in i:
            b.append(j)
print(b)
print("the sum of b:",sum(b))
