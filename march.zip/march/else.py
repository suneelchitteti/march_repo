print("begin")
x=input("enter number:")
i=int(x)
if i<10:
    print("the givern number is 1 digit number")
else:
    print("the given number is more than 1 digit number")
print("end")
