#first non default after that default program is executed
def add(a,b=20):
    c=a+b
    print(c)
add(100)
add(120,123)
#first default after that non default program will not be executed compilation error
def add( a=12,b):
    c=a+b
    print(c)
add(12,34)
