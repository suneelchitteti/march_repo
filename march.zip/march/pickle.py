import pickle
data=[["suneel",1234,2000.00],
      ["sai",12345,3000.00],
      ["surya",123456,4000.00]]
x=open("picfile.txt","wb")
pickle.dump(data,x)
x.close()
a=open("picfile.txt","rb")
b=pickle.load(a)
for p in b:
    print(p )
print(b)
