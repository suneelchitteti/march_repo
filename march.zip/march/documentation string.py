def myfunc():
    """sample test to display the documentation string"""
    print("welcome")
myfunc()
help(myfunc)
