def add(**a):
    print(a)
    print(type(a))
    print(len(a))
add(a=1,b=2,c=3)

