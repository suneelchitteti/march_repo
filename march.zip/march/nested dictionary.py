x={"java":["spring","structs","jsf"],"python":["django","flask","web2py"],".net":["mvc","wcf","wpf"]}
print(x)
for k,v in x.items():
    print(k)
    print("*********")
    for p in v:
        print(p)
