from itertools import accumulate
for i in accumulate([1,2,3,4,5]):
    print(i)
a=[1,2,3,[4,5],(6,7,8),"suneel"]
print(a)
b=[]
for i in a:
   # print(i)
    if type(i)==int:
        #print(i)
        b.append(i)
        #print(b)
    elif type(i)==list:
        for q in i:
            #print(q)
            b.append(q)
            #print(b)
        #print(i)
    elif type(i)==tuple:
        for r in i:
            b.append(r)
            #print(b)
        #print(i)
    elif type(i)==str:
        for s in i:
            b.append(s)
        #print(i)
print(b)
