x="suneel"
print(x)
print(type(x))
print(x.capitalize())
print(x.title())
print(x.upper())
print(x.lower())
print(x.isdigit())
print(x.islower())
print(x.isupper())

print("next program")
y="12345"
print(y)
print(type(y))
print(y.isdigit())
print(y.islower())
print(y.isupper())

print("next program")
z="suneel is looking for python developer job"
w=z.split()
for p in w:
    print(p,len(p),p.upper())

