s=[[1,2,3],[4,5],[6,7,8]]
a=[]
for i in s:
    #print(i)
    if type(i)==list:
        for j in i:
            #print(j)
            a.append(j)
print(a)
