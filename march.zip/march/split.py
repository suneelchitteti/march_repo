a="suneel is looking for python developer job"
b=a.split()
print(b)
e=reversed(b)
print(e)
for c in b:
    print(c)
    d=reversed(c)
print(d)
