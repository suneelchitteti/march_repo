'''for i in range(1,100):
    if i%3==0:
        print("suneel")
    else:
        print(i)
print("***next program*****")
for i in range(1,50):
    if i%2==0:
        print(i,"*",54,"=",i*54)
'''
print("\t\t multiplication table")
print("\t***************************************")
for i in range(1,11):
    print(i,end="  ")
print("\n**************************")    
for j in range(1,11):
        print("\n",j)        
