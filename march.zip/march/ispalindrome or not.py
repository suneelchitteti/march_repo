def ispalindrome(s):
    rev=s[::-1]
    if(s==rev):
        print(s,"is palindrome")
    else:
        print(s,"is not a palindrome")
s=input("enter a string:")
ispalindrome(s)
