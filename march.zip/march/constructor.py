class Test:
    def __init__(self):
        print("in constructor of class test")
    def m1(self):
        print("in method of class test")
t1=Test()
t1.m1()
t2=Test()
t2.m1()
