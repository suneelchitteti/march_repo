class x:
    def m1(self):
        print("in m1 of class x no param")
    def m1(self,a):
        print("in m2 of class x of one param")
    def m1(self,a,b):
        print("in m1 of class x of two param")
x1=x()
#x1.m1()
#x1.m1(100)
x1.m1(100,200)
