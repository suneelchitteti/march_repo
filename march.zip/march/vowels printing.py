w=input("enter a word for search a vowels:")
s=set(w)
v={'a','e','i','o','u'}
d=s.intersection(v)
print("the difference vowels present in w are:",d)
