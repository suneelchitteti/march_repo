def add(a,b):
    c=a+b
    print(c)
add(100,200)
add(123,123)
add(234,234)
