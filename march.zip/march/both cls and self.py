class Test:
    def m1(cls,self):
        cls.x=10
        print("instance method:",cls.x,self)
t=Test()
t.m1("suneel")
print("***********next program***********")
class Test:
    def m1(self,name):
        self.x=10
        print("instance method:",self.x,name)
t=Test()
t.m1("suneel")
