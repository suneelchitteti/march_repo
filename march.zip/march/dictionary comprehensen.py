x={p:p for p in range(5)}
print(x)
y={p:p*p for p in range(10) if p%2==0}
print(y)
z={p:p*2 for p in range(10) if p%2!=0}
print(z)
