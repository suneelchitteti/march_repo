class Test:
    def m1(self):
        a=100
        b=200
        print(a)
        print(b)
    def m2(self):
        c=300
        d=400
        print(c)
        print(d)
t1=Test()
t1.m1()
t1.m2()
