x=input("enter a string:")
a={}.fromkeys(x,0)
for b in x:
    if b in a.keys():
        a[b]+=1
        #print(b)
for k,v in a.items():
    print(str(v)+k,end="")
