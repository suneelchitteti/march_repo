p=65
b=chr(p)
print(b)
q="s"
a=ord(q)
print(a)
a="a"
b=ord(a)
print(b)
c=97
d=chr(c)
print(d)
e="suneel"
print("initial string:",e)
result=''.join(map(ord,e))
print("resulting string:",result)
