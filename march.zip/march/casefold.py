s="suneel SUNEEL SuNEeL suneel23"
for i in s.split():
    if i.casefold()=="suneel":
        print(i)
