class suneelmath:
    #@staticmethod
    def add(x,y):
        print("the sum:",x+y)
    #@staticmethod
    def product(x,y):
        print("the product:",x*y)
    #@staticmethod
    def average(x,y):
        print("the average:",(x+y)/2)
suneelmath.add(100,200)
suneelmath.product(200,300)
suneelmath.average(300,400)
print("*****************next program***************")
'''class Test:
    def m1():
        print("some method")

t=Test()
t.m1()'''
# the above program is invalid because of python will consider the method as
#instance method but we are not declaring the self variable hence we are getting in error
class Test:
    @staticmethod
    def m1():
        print("suneel")
t=Test()
t.m1()
print("******next programs*********")
class Test:
    def m1():
        print("suneel kumar")
Test.m1()

