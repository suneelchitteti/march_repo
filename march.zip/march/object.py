print("begin")
class Test:
    """sample class to test the object"""
    def display(self):
        print("welcome")

t1=Test()
print(t1)
t1.display()
print(id(t1))
t2=Test()
print(t2)
t2.display()
print(id(t2))
