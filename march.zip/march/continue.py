print("begin")
i=0
while i<=10:
    i=i+1
    if i==3:
        continue
    print("welcome",i)
