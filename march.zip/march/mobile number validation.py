import re
n=input("enter a mobile number:")
m=re.fullmatch("[6-9]\d{9}",n)
if m!=None:
    print("the mobile number is valid")
else:
    print("the mobile number is not valid")
