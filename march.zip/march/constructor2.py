class Test:
    def __init__(self,a,b):
        self.a=a
        self.b=b
    def display(self):
        print(self.a)
        print(self.b)
t1=Test(100,200)
t1.display()
t2=Test(300,400)
t2.display()
        
