a=range(1,11)
for x in a:
    print(2,"*",x,"=",x*x)
