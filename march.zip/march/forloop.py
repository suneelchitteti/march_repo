x="suneel"
for p in x:
    print(p*3)
