a={1,2,3,4,5}
print(a)
b={4,5,6,7,8}
print(b)
print(a.union(b))
print(b.union(a))
print(a.intersection(b))
print(b.intersection(a))
print(a.difference(b))
print(b.difference(a))
print(a.symmetric_difference(b))
print(b.symmetric_difference(a))
print("*****next program*****")
s={(10,20,30),(40,50,60),(70,80,90)}
print(s)
print(type(s))
for p in s:
    print(p,type(p))
    for q in p:
        print(q)
