x="suneel"
print(x)
print(x[2])
print(x[:2])
print(x[2:])
print(x[2:6])
print(x[-2])
print(x[-2:-6])
