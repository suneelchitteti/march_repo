while True:
    name=input("enter user name:")
    if name!="suneel":
        print("wrong user name enter correct user name")
        continue
    password=input("hello suneel what is your password:")
    if password=="python":
        break
print("access granted")
    
