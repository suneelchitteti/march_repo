x="suneel"
print(x)
print('k' in x)
print('k' not in x)
print('s' in x)
print('s' not in x)
