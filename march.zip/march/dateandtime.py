import datetime
date=datetime.datetime.now()
print("it's now:{:%d/%m/%y %H:%M:%S}".format(date))
t=()
print(type(t))
t=10,20,30,40
print(type(t))
t=10
print(type(t))
t=10,
print(type(t))
t=(10)
print(type(10))
t=(10,)
print(type(t))
t=(10,20,30,40)
print(type(t))
