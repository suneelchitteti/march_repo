s={100:"suneel",200:"sairam",300:"surya"}
print(s)
print(type(s))
del s[100]
print(s)
s[400]="suneel"
print(s)
for i in s.keys():
    print(i)
sum=sum(s.keys())
print("sum:",sum)
