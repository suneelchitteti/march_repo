x=(p for p in range(10))
print(x)
print(type(x))
