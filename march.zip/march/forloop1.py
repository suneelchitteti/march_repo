for i in range(5):
    for j in range(5):
        for k in range(5):
            print("k:",k)
            print("j:",k)
            print("i:",i)
