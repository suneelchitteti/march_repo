class suneel:
    count=0
    def __init__(self):
        suneel.count=suneel.count+1
    @classmethod
    def getnoobjects(cls):
        print("the no of objects are created:",cls.count)
s1=suneel()
s2=suneel()
suneel.getnoobjects()
print("****************next program***************")
class suneel:
    legs=2
    @classmethod
    def walks(cls,name):
        print("{} walks with {} legs".format(name,cls.legs))
s1=suneel()
print(s1)
suneel.walks("suneel")
