x=int(input("enter a number:"))
n1=0
n2=1
count=0
if x<=0:
    print("please enter positive number")
elif x==1:
    print("the fibonacci sequence upto",x,":")
    print(n1)
else:
    print("the fibonacci sequence upto",x,":")
    while count<x:
        print(n1,end=",")
        n=n1+n2
        n1=n2
        n2=n
        count+=1
