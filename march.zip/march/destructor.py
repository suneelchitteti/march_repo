class Test:
    def __init__(self):
        print("in constructor of test")
    def display(self):
        print("welcome")
    def __del__(self):
        print("destructor of a class test")
t1=Test()
print(t1)
t1.display()
t2=Test()
t2.display()
t1=Test()
t1.display()
Test().display()
del t1
del t2
