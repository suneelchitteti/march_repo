class Test:
    def __init__(self):
        print("in constructor of class test")
    def display(self):
        print("welcome")
t1=Test()
print(t1)
t1.display()
