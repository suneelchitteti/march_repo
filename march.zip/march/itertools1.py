from itertools import combinations
a=["abc","ab","abcd"]
b=combinations(a)

print(b)
