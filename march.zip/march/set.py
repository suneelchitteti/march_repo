x={}
print(type(x))
y=set()
print(type(y))
a={10,20,30,40,50,30,40,10}
print(type(a))
print(a)
b=list(a)
print(b)
c=tuple(a)
print(c)
d=list(c)
print(d)
p=list(a)
print(p)

