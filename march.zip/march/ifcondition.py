print("begin")
x=input("enter number:")
i=int(x)
if i<10:
    print("the given number is 1 digit number")
print("end")
