class Test:
    """sample class to test the static variables"""
    a=1000
    b=2000
    def display(self):
        print(Test.a)
        print(Test.b)
    def modify(self):
        Test.a=Test.a+100
        Test.b=Test.b-100
t1=Test()
print(t1)
t1.display()
t1.modify()
t1.display()
t2=Test()
print(t2)
t1.display()
t1.modify()
t1.display()
