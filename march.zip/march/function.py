print("begin")
def myfunc():
    print("welcome")
    #print("end")
myfunc()
a=myfunc
print(a)
  
