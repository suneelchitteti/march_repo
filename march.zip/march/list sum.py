a=[1,2,3,[4,5,6],7,[8,9,10]]
c=[]
for i in a:
    if type(i)==int:
            c.append(i)
            #print(c)
    if type(i)==list:
        for j in i:
            #print(j)
            c.append(j)
            #print(c)
print(c)
print(sum(c))
print("*****next program*****")
s=[1,2,[3,4,5],(6,7,8),{9,2,3}]
a=[]
for i in s:
    #print(i)
    if type(i)==int:
        a.append(i)
        #print(a)
    if type(i)==list:
        for j in  i:
            a.append(j)
            #print(a)
    if type(i)==tuple:
        for k in i:
            a.append(k)
            #print(a)
    if type(i)==set:
        for l in i:
            a.append(l)
            #print(a)
print(a)
print(sum(a))
