print("begin")
x=input("enter number:")
i=int(x)
if i<10:
    print("the given number is 1 digit number")
elif i<100:
    print("the given number is 2 digit number")
elif i<1000:
    print("the given number is 3 digit number")
else:
    print("the given number is more than 3 digit number")
print("end")
 
