from itertools import permutations
a="abc"
for i in permutations(a):
    print(''.join(i))
