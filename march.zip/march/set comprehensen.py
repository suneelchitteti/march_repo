x={p for p in range(10)}
print(type(x))
print(x)
y={p for p in range(10) if p%2==0}
print(type(x))
print(y)
