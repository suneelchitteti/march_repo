import re
n=input("enter mail:")
m=re.fullmatch("[a-zA-Z0-9_.]*@gmail[.]com",n)
if m!=None:
    print("the mail id is valid")
else:
    print("the mail id is not valid")
