a=[1,2,3,4,'a','b','x','p','t',5]
b=sum([x for x in a if isinstance(x,int)])
print("the sum of integers are:",b)
c=sorted([y for y in a if isinstance(y,str)])
print("the sorted of strings are:",c)

for m in a:
    if isinstance(m,str):
        d=m
        e=sorted(d)
        print(e)
