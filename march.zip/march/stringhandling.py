print("*********by using single qutos******")
a='suneel kumar'
print(a)
print(type(a))
print(id(a))
print(len(a))
print("*******by using triple qutos******")
b='''suneel
is
looking
for
python
developer
job'''
print(b)
print(type(b))
print(id(b))
print(len(b))
