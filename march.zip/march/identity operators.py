a=1000
print(id(a))
b=2000
print(id(b))
print(a==b)
print(a!=b)
print(a is b)
print(a is not b)
print("***next program******")
c=3000
print(id(c))
d=3000
print(id(d))
print(c==d)
print(c!=d)
print(c is d)
print(c is not d)
print("*********next program*******")
p=[10,20,30]
print(id(p))
q=[40,50,60]
print(id(q))
print(p==q)
print(p!=q)
print(p is q)
print(p is not q)
r=[70,80,90]
print(id(r))
s=[70,80,90]
print(id(s))
print(r==s)
print(r!=s)
print(r is s)
print(r is not s)
