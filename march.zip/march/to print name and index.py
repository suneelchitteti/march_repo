x=["suneel","surya","ramana","sai"]
i=0
print(x)
print("NAME\tINDEX")
print("******\t******")
for p in x:
    print(p,"\t",i)
    i=i+1
