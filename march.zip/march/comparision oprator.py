x=19
y=5
print(x<y)
print(x<=y)
print(x>y)
print(x>=y)
print(x==y)
print(x!=y)
