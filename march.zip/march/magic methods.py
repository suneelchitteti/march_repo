class employee:
    def __init__(self):
        self.name="suneel"
        self.salary=40000
    def display(self):
        print(self. name)
        print(self.salary)
e1=employee()
print(e1)
e1.display()

