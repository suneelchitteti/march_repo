x=((10,20,30),(40,50,60),(70,80,90))
print(x)
print(type(x))
for p in x:
    print(p,len(p))
    for q in p:
        print(q)
