x=[]
for p in range(10):
    print(p)
    x.append(p)
print(x)

x=[p for p in range(10)]
print(x)
a=[p*p for p in range(10,20) if p%2==0]
print(a)
b=[p**2 for p in range(20,30) if p%2!=0]
print(b)
