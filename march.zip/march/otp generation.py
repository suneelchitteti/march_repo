import math,random
def generateOTP():
    digits="0123456789"
    OTP=""
    for i in range(4):
        OTP+=digits[math.floor(random.random()*10)]
    return OTP
otp=generateOTP()
print("the 4 digit otp is:",otp)
