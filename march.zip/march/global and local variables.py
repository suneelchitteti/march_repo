a=100
b=200
def f1():
    global c,d 
    c=300
    d=400
    print(a)
    print(b)
    print(c)
    print(d)
def f2():
    e=500
    f=600
    print(a)
    print(b)
    print(c)
    print(d)
    print(e)
    print(f)
f1()
f2()
