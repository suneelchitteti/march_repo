print("begin")
class Test:
    """sample class to  test the static variables"""
    a=10
    b=20
    def display(self):
        print(Test.a)
        print(Test.b)
        
t1=Test()
print(t1)
t1.display()
print(Test.a)
print(Test.b)
print(t1.a)
print(t1.b)
print("end")
