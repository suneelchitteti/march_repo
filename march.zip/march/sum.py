x=10
y=20
z=x+y
print(x)
print(y)
print(z)
print(type(x))
print(type(y))
print(type(z))
print(id(x))
print(id(y))
print(id(z))
a=x-y
b=x*y
c=x/y
print("substract of a:",a)
print("multiplication of b:",b)
print("division of c:",c)
print("sum of z:", z)
